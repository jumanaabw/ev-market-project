"""Page and JSON API routes."""
from __future__ import annotations

from flask import Blueprint, current_app, jsonify, render_template

import config
from evmarket import analysis

bp = Blueprint("main", __name__)

CHART_FILES = [
    ("sales_by_category.png", "Annual sales by category"),
    ("battery_durability.png", "Battery durability"),
    ("price_vs_range.png", "Price vs range"),
    ("co2_by_category.png", "CO2 saved by category"),
]


def _db() -> str:
    return current_app.config["DB_PATH"]


# --- pages ----------------------------------------------------------------
@bp.route("/")
def home():
    return render_template("index.html", kpis=analysis.kpis(_db()))


@bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", viz_url=current_app.config["DASHBOARD_URL"])


@bp.route("/story")
def story():
    return render_template("story.html", viz_url=current_app.config["STORY_URL"])


@bp.route("/insights")
def insights():
    path = _db()
    categories = analysis.sales_by_category(path)
    available = [
        (name, label) for name, label in CHART_FILES
        if (config.BASE_DIR / "webapp" / "static" / "charts" / name).is_file()
    ]
    return render_template(
        "insights.html",
        kpis=analysis.kpis(path),
        findings=analysis.insights(path),
        categories=analysis.to_records(categories),
        max_sales=float(categories["total_sales"].max()) if len(categories) else 1.0,
        batteries=analysis.to_records(analysis.battery_comparison(path)),
        manufacturers=analysis.to_records(analysis.top_manufacturers(path)),
        regions=analysis.to_records(analysis.region_summary(path)),
        segments=analysis.to_records(analysis.price_segments(path)),
        best_value=analysis.to_records(analysis.best_value_models(path)),
        corr=analysis.correlations(path),
        charts=available,
    )


@bp.route("/about")
def about():
    return render_template(
        "about.html",
        demo_url=current_app.config["DEMO_VIDEO_URL"],
        dashboard_url=current_app.config["DASHBOARD_URL"],
        story_url=current_app.config["STORY_URL"],
    )


# --- JSON API -------------------------------------------------------------
API_TABLES = {
    "sales-by-category": analysis.sales_by_category,
    "top-manufacturers": analysis.top_manufacturers,
    "battery": analysis.battery_comparison,
    "regions": analysis.region_summary,
    "yearly": analysis.yearly_trend,
    "price-segments": analysis.price_segments,
    "co2": analysis.co2_by_category,
    "best-value": analysis.best_value_models,
}


@bp.route("/api/kpis")
def api_kpis():
    return jsonify(analysis.kpis(_db()))


@bp.route("/api/correlations")
def api_correlations():
    return jsonify(analysis.correlations(_db()))


@bp.route("/api/<name>")
def api_table(name: str):
    func = API_TABLES.get(name)
    if func is None:
        return jsonify(error=f"Unknown dataset '{name}'", available=sorted(API_TABLES)), 404
    return jsonify(analysis.to_records(func(_db())))


@bp.route("/health")
def health():
    return jsonify(status="ok", rows=analysis.kpis(_db())["total_rows"])
