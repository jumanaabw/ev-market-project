"""Flask application factory for the EV Market Analytics site."""
from __future__ import annotations

from flask import Flask, render_template

import config
from evmarket import db


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=config.SECRET_KEY,
        DB_PATH=str(config.DB_PATH),
        AUTO_BUILD_DB=True,          # build the SQLite file from the CSV on first start
        DASHBOARD_URL=config.DASHBOARD_URL,
        STORY_URL=config.STORY_URL,
        PROJECT_TITLE=config.PROJECT_TITLE,
        PROJECT_SUBTITLE=config.PROJECT_SUBTITLE,
        AUTHOR=config.AUTHOR,
        PROGRAM=config.PROGRAM,
        GITHUB_URL=config.GITHUB_URL,
        DEMO_VIDEO_URL=config.DEMO_VIDEO_URL,
    )
    if test_config:
        app.config.update(test_config)

    if app.config["AUTO_BUILD_DB"]:
        db.ensure_database(app.config["DB_PATH"])

    from .routes import bp
    app.register_blueprint(bp)

    @app.template_filter("thousands")
    def thousands(value, decimals: int = 0):
        try:
            return f"{float(value):,.{decimals}f}"
        except (TypeError, ValueError):
            return "-"

    @app.template_filter("compact")
    def compact(value):
        try:
            v = float(value)
        except (TypeError, ValueError):
            return "-"
        for limit, suffix in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
            if abs(v) >= limit:
                return f"{v / limit:.1f}{suffix}"
        return f"{v:.0f}"

    @app.context_processor
    def inject_globals():
        return {
            "project_title": app.config["PROJECT_TITLE"],
            "project_subtitle": app.config["PROJECT_SUBTITLE"],
            "author": app.config["AUTHOR"],
            "program": app.config["PROGRAM"],
            "github_url": app.config["GITHUB_URL"],
        }

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    return app
