# Global Electric Vehicle Market Analysis

Performance, pricing, battery technology and sales across 100,000 EV models,
analysed with **Python, SQL (SQLite), Tableau Public and Flask**.

SmartBridge Skill Wallet project: *Data Analytics with Tableau*  
Author: **Nilamber Singh Hada**

- Tableau dashboard: https://public.tableau.com/views/EVMarketAnalysis_17926786113420/MarketOverview
- Tableau story: https://public.tableau.com/views/EVMarketAnalysis_17926786113420/Story1
- Demo video: https://drive.google.com/file/d/1Oik0Z53AKzTwvmX7_oB2swu_yIT3qbFW/view?usp=drivesdk

## What the project does

```
CSV  ──►  SQLite (ev_market + vw_ev_clean)  ──►  SQL analysis  ──►  Tableau dashboard + story
                                      │                                      │
                                      └──────────►  Flask website  ◄─────────┘
                                                   (embeds Tableau, live insights, JSON API)
```

1. **Load** the dataset (37 columns) into a SQLite table and add a clean view with derived fields.
2. **Query** it with nine SQL queries (counts, aggregates, grouping, sorting, calculated columns, a view).
3. **Visualize** it in Tableau (12 visualizations, 6 calculated fields, 6 filters, a 6-scene story).
4. **Publish** everything on a Flask site with Home, Dashboard, Story, Insights and About pages.

## Quick start

Requires Python 3.11 or newer (tested on 3.13; CI covers 3.11 to 3.13).

```bash
git clone https://github.com/NilamberHada/ev-market-tableau.git
cd ev-market-tableau

python -m venv .venv
# Windows:        .venv\Scripts\activate
# macOS / Linux:  source .venv/bin/activate

pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000. On first start the SQLite database (`ev_market.db`) is built
automatically from the dataset CSV, so there is no separate setup step.

> **Which data is used?** The repo ships `data/ev_market_sample.csv`, a 10,000-row *synthetic*
> sample, so it runs immediately. To use the official 100,000-row Skill Wallet file, copy
> `ev_market_test.csv` into `data/` (or the repository root). The database rebuilds itself when
> the CSV changes. See [data/README.md](data/README.md).

## Project structure

```
ev-market-tableau/
├── run.py                    # start the website
├── config.py                 # paths, Tableau links, project details (env-overridable)
├── requirements*.txt         # base, dev (tests), mysql (optional), deploy (gunicorn)
├── data/
│   ├── ev_market_sample.csv  # synthetic sample (10,000 rows)
│   └── README.md             # data dictionary and how to use the official CSV
├── sql/
│   ├── queries.sql           # the 9 analysis queries
│   └── create_view.sql       # vw_ev_clean (derived fields)
├── evmarket/                 # core library
│   ├── schema.py             # the 37 columns
│   ├── generator.py          # synthetic dataset generator
│   ├── db.py                 # CSV -> SQLite, view, query helper
│   ├── sqlfile.py            # parser for queries.sql
│   └── analysis.py           # query wrappers, correlations, insights
├── scripts/
│   ├── generate_dataset.py   # make a synthetic CSV (any size)
│   ├── load_to_db.py         # CSV -> SQLite
│   ├── run_queries.py        # run and print every SQL query
│   ├── make_charts.py        # PNG charts for the README / Insights page
│   ├── export_tableau_csv.py # export the clean view for Tableau
│   └── load_to_mysql.py      # optional MySQL loader
├── webapp/                   # Flask app (templates, CSS, JS, charts)
├── tableau/README.md         # calculated fields, filters, worksheets, story
├── tests/                    # pytest suite
└── .github/workflows/ci.yml  # runs the tests on every push
```

## Commands

| Task | Command |
|------|---------|
| Start the website | `python run.py` (add `--port 8000` or `--debug`) |
| Load CSV into SQLite | `python scripts/load_to_db.py` |
| Run all SQL queries | `python scripts/run_queries.py` |
| Run one query / pause between queries (for screenshots) | `python scripts/run_queries.py --only 4` / `--pause` |
| Regenerate PNG charts | `python scripts/make_charts.py` |
| Export CSV for Tableau | `python scripts/export_tableau_csv.py` |
| Generate a 100k synthetic CSV | `python scripts/generate_dataset.py --rows 100000 --out data/ev_market_test.csv` |
| Run the tests | `pip install -r requirements-dev.txt` then `python -m pytest` |

## SQL queries

| # | Name | What it answers |
|---|------|-----------------|
| 1 | overview | Rows, manufacturers, categories, countries, years, total sales |
| 2 | top_manufacturers | Who sells the most? |
| 3 | sales_by_category | Sales and average price per category |
| 4 | battery_comparison | Range, fast-charge time, cycle life and degradation per battery type |
| 5 | region_summary | Models, price and rating per region |
| 6 | yearly_trend | Models, range, price and sales per model year |
| 7 | price_segments | Budget / Mid-range / Premium / Luxury (uses the view) |
| 8 | co2_by_category | CO2 saved per category |
| 9 | best_value_models | Cars with the most range per $1,000 |

## Website

| Route | Content |
|-------|---------|
| `/` | Headline numbers and links |
| `/dashboard` | Embedded Tableau dashboard |
| `/story` | Embedded Tableau story (6 scenes) |
| `/insights` | Findings, tables and charts computed live from the database |
| `/about` | Objectives, business questions, links |
| `/api/kpis`, `/api/correlations` | JSON headline numbers |
| `/api/<dataset>` | JSON: `sales-by-category`, `top-manufacturers`, `battery`, `regions`, `yearly`, `price-segments`, `co2`, `best-value` |
| `/health` | `{"status": "ok", "rows": N}` |

Light and dark themes follow the system setting and can be toggled from the top bar.

### Changing the Tableau links or database location

Set environment variables instead of editing code:

| Variable | Purpose |
|----------|---------|
| `TABLEAU_DASHBOARD_URL`, `TABLEAU_STORY_URL` | Links embedded on the Dashboard and Story pages |
| `EV_CSV_PATH` | Use a CSV from another location |
| `EV_DB_PATH` | Where the SQLite file is stored |
| `SECRET_KEY` | Flask secret key (set this when deploying) |

## Key findings (from the project report)

- **Scooters lead volume** (about 85M units), then sedans (78M) and compact SUVs (76M); trucks, pickups and buses sell 5 to 7M each.
- **Price follows battery size:** correlation 0.84 with battery capacity but only 0.28 with range. Buses (about $274k) and trucks (about $169k) cost the most.
- **Battery durability:** Solid-State averages 2,999 cycles and 7.36% degradation over five years; LFP follows with 2,498 cycles and 10.11%. NMC, Sodium-Ion and NCA sit between 1,598 and 1,799 cycles with about 14% degradation.
- **No fast-charge or range gap** between chemistries: about 21 minutes and 320 to 325 km for every type.
- **Balanced market:** the top five manufacturers sell 4.6M to 4.9M units each, and regions are evenly split.

Those figures come from the official dataset. The Insights page recomputes the same measures from
whatever data is loaded, so with the bundled synthetic sample the numbers are similar in shape
but not identical.

**Limitation:** the dataset is synthetic, so summed sales (about 773 million units) and estimated
revenue are relative measures, not real-world totals.

## Deployment (optional)

```bash
pip install -r requirements-deploy.txt
gunicorn "webapp:create_app()"
```

A `Procfile` is included for platforms that read one (Render, Railway, Heroku). Set `SECRET_KEY`
and, if the official CSV is not in the repo, `EV_CSV_PATH`. This deployment path has not been
tested end to end.

## Future scope

- Add real-world data (registrations, charging stations) to replace synthetic fields.
- Add sales forecasting by category.
- Connect Tableau directly to a MySQL server with Tableau Desktop (`scripts/load_to_mysql.py` is a starting point).
- Deploy the Flask app to a cloud platform.

## License

MIT, see [LICENSE](LICENSE).
