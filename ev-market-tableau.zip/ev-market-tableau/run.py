"""Start the EV Market Analytics website.

    python run.py                    # http://127.0.0.1:5000
    python run.py --port 8000 --debug

On first start the SQLite database is built automatically from the dataset
CSV (see config.py for the search order).
"""
import argparse

from webapp import create_app


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--debug", action="store_true", help="enable Flask debug mode and auto-reload")
    args = parser.parse_args()

    app = create_app()
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
