# Data

| File | What it is |
|------|-----------|
| `ev_market_sample.csv` | 10,000-row **synthetic** sample with the same 37 columns as the official dataset. It lets the project run straight after cloning. |
| `ev_market_test.csv` | *(not included)* The official 100,000-row Skill Wallet dataset. Put it here (or in the repository root) and the project uses it automatically. |

## Using the official dataset

1. Copy `ev_market_test.csv` into this folder.
2. Start the app (`python run.py`) or run `python scripts/load_to_db.py`.
   The database is rebuilt automatically whenever the CSV changes.

## Generating more synthetic data

```bash
python scripts/generate_dataset.py --rows 100000 --out data/ev_market_test.csv
```

The generator reproduces the category mix and the category and battery averages
published in the project report, so the shape of the results is similar, but the
values are made up. Do not quote them as real market statistics.

## The 37 columns

| Group | Columns |
|-------|---------|
| Identity | vehicle_id, model_name, manufacturer, model_year, manufacturing_country, market_region, category |
| Battery | battery_capacity_kwh, battery_type, battery_cycle_life, battery_degradation_pct_5yr |
| Performance | range_km, efficiency_wh_per_km, motor_power_kw, torque_nm, num_motors, drivetrain, top_speed_kmph, acceleration_0_100_sec |
| Charging | max_dc_charging_kw, charging_dc_fast_time_min, charging_ac_time_hr, num_charging_ports |
| Body and features | num_seats, weight_kg, cargo_capacity_liters, infotainment_screen_inch, autonomous_level, safety_rating_stars |
| Commercial | price_usd, insurance_cost_usd_yearly, warranty_years, resale_value_pct_3yr, annual_sales_units, customer_rating |
| Impact and use | co2_saved_tons_per_year, recommended_use_case |

Five columns have a few blank values (`resale_value_pct_3yr`, `battery_cycle_life`,
`customer_rating`, `infotainment_screen_inch`, `annual_sales_units`). They are left
blank so averages ignore them.
