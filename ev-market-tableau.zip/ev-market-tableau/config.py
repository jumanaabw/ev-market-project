"""Central configuration for the EV Market Analysis project.

Everything that may change between machines (database location, Tableau
links, author details) lives here, so no other file needs editing.
Each value can be overridden with an environment variable.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
SQL_DIR = BASE_DIR / "sql"

# --- Database -----------------------------------------------------------
DB_PATH = Path(os.environ.get("EV_DB_PATH", BASE_DIR / "ev_market.db"))
TABLE_NAME = "ev_market"
VIEW_NAME = "vw_ev_clean"
META_TABLE = "ev_meta"

# CSV files are searched in this order; the first one that exists is used.
#   1. EV_CSV_PATH environment variable
#   2. data/ev_market_test.csv   (the official Skill Wallet dataset)
#   3. ev_market_test.csv        (repository root, where the original repo kept it)
#   4. data/ev_market_sample.csv (small synthetic sample shipped with this repo)
CSV_CANDIDATES = [
    DATA_DIR / "ev_market_test.csv",
    BASE_DIR / "ev_market_test.csv",
    DATA_DIR / "ev_market_sample.csv",
]
if os.environ.get("EV_CSV_PATH"):
    CSV_CANDIDATES.insert(0, Path(os.environ["EV_CSV_PATH"]))

# --- Tableau Public links (embedded by the Flask app) --------------------
DASHBOARD_URL = os.environ.get(
    "TABLEAU_DASHBOARD_URL",
    "https://public.tableau.com/views/EVMarketAnalysis_17926786113420/MarketOverview",
)
STORY_URL = os.environ.get(
    "TABLEAU_STORY_URL",
    "https://public.tableau.com/views/EVMarketAnalysis_17926786113420/Story1",
)

# --- Project details shown on the About page ------------------------------
PROJECT_TITLE = "Global Electric Vehicle Market Analysis"
PROJECT_SUBTITLE = "Performance, pricing, battery technology and sales"
AUTHOR = "Nilamber Singh Hada"
PROGRAM = "SmartBridge Skill Wallet - Data Analytics with Tableau"
GITHUB_URL = "https://github.com/NilamberHada/ev-market-tableau"
DEMO_VIDEO_URL = os.environ.get(
    "DEMO_VIDEO_URL",
    "https://drive.google.com/file/d/1Oik0Z53AKzTwvmX7_oB2swu_yIT3qbFW/view?usp=drivesdk",
)

# --- Flask ----------------------------------------------------------------
SECRET_KEY = os.environ.get("SECRET_KEY", "dev-only-change-me")
