"""Load the EV market CSV into a SQLite database (table ev_market + view vw_ev_clean).

Examples
--------
    python scripts/load_to_db.py                          # auto-detect the CSV
    python scripts/load_to_db.py --csv ev_market_test.csv --db ev_market.db
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from evmarket import db  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--csv", type=Path, help="path to the dataset CSV (default: auto-detect)")
    parser.add_argument("--db", type=Path, default=config.DB_PATH, help="SQLite file to create")
    args = parser.parse_args()

    csv = db.resolve_csv(args.csv)
    if csv is None:
        sys.exit(
            "No dataset found. Put ev_market_test.csv in data/ or run:\n"
            "  python scripts/generate_dataset.py"
        )
    print(f"Found dataset: {csv}")
    rows = db.load_csv(csv, args.db)
    print(f"Stored {rows:,} rows in table {config.TABLE_NAME} (database file: {args.db})")


if __name__ == "__main__":
    main()
