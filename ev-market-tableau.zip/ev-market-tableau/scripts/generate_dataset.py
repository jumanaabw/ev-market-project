"""Generate a synthetic EV market CSV with the project's 37 columns.

Examples
--------
    python scripts/generate_dataset.py                       # 10,000-row sample -> data/ev_market_sample.csv
    python scripts/generate_dataset.py --rows 100000 --out data/ev_market_test.csv
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from evmarket.generator import generate  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--rows", type=int, default=10_000, help="number of rows (default 10000)")
    parser.add_argument("--seed", type=int, default=42, help="random seed (default 42)")
    parser.add_argument("--out", type=Path, default=config.DATA_DIR / "ev_market_sample.csv", help="output CSV path")
    args = parser.parse_args()

    df = generate(args.rows, args.seed)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows x {df.shape[1]} columns to {args.out}")
    print("Note: the data is synthetic and meant for demonstration only.")


if __name__ == "__main__":
    main()
