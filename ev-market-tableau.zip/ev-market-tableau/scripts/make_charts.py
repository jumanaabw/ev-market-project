"""Create the static PNG charts shown in the README and on the Insights page.

Charts: sales by category, battery durability, price vs range, CO2 saved.
Output goes to webapp/static/charts/.

Example
-------
    python scripts/make_charts.py
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import config  # noqa: E402
from evmarket import analysis, db  # noqa: E402

GREEN = "#1f9e76"
DARK = "#123f2f"
OUT_DIR = config.BASE_DIR / "webapp" / "static" / "charts"


def _style(ax):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def chart_sales_by_category(db_path, out_dir):
    df = analysis.sales_by_category(db_path).sort_values("total_sales")
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.barh(df["category"], df["total_sales"] / 1e6, color=GREEN)
    ax.set_xlabel("Annual sales units (millions)")
    ax.set_title("Annual sales by category")
    _style(ax)
    fig.tight_layout()
    fig.savefig(out_dir / "sales_by_category.png", dpi=130)
    plt.close(fig)


def chart_battery(db_path, out_dir):
    df = analysis.battery_comparison(db_path).sort_values("avg_cycle_life")
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(9, 4), sharey=True)
    a1.barh(df["battery_type"], df["avg_cycle_life"], color=GREEN)
    a1.set_title("Average cycle life")
    a2.barh(df["battery_type"], df["avg_degradation_pct"], color=DARK)
    a2.set_title("Average 5-year degradation (%)")
    for ax in (a1, a2):
        _style(ax)
    fig.tight_layout()
    fig.savefig(out_dir / "battery_durability.png", dpi=130)
    plt.close(fig)


def chart_price_vs_range(db_path, out_dir):
    df = analysis.price_range_sample(6000, db_path=db_path)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(df["price_usd"] / 1000, df["range_km"], s=5, alpha=0.35, color=GREEN, linewidths=0)
    ax.set_xlabel("Price (USD thousands)")
    ax.set_ylabel("Range (km)")
    ax.set_title("Price vs range (6,000-row sample)")
    _style(ax)
    fig.tight_layout()
    fig.savefig(out_dir / "price_vs_range.png", dpi=130)
    plt.close(fig)


def chart_co2(db_path, out_dir):
    df = analysis.co2_by_category(db_path).head(8).sort_values("total_thousand_tons")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.barh(df["category"], df["total_thousand_tons"], color=DARK)
    ax.set_xlabel("CO2 saved (thousand tons / year)")
    ax.set_title("CO2 saved by category (top 8)")
    _style(ax)
    fig.tight_layout()
    fig.savefig(out_dir / "co2_by_category.png", dpi=130)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", type=Path, default=config.DB_PATH)
    parser.add_argument("--out", type=Path, default=OUT_DIR)
    args = parser.parse_args()

    db.ensure_database(args.db)
    args.out.mkdir(parents=True, exist_ok=True)
    for fn in (chart_sales_by_category, chart_battery, chart_price_vs_range, chart_co2):
        fn(args.db, args.out)
    print(f"Saved charts to {args.out}")
    for f in sorted(args.out.glob("*.png")):
        print(f"  {f.name}")


if __name__ == "__main__":
    main()
