"""Export the clean view (vw_ev_clean) to a CSV that can be opened directly in Tableau.

The file contains every original column plus the derived fields
(range_per_1000usd, price_segment, range_class, fast_charge_rating, revenue_est).

Example
-------
    python scripts/export_tableau_csv.py --out tableau/ev_market_tableau_ready.csv
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from evmarket import db  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", type=Path, default=config.DB_PATH)
    parser.add_argument("--out", type=Path, default=config.BASE_DIR / "tableau" / "ev_market_tableau_ready.csv")
    args = parser.parse_args()

    db.ensure_database(args.db)
    df = db.run_query(f"SELECT * FROM {config.VIEW_NAME}", db_path=args.db)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows x {df.shape[1]} columns to {args.out}")


if __name__ == "__main__":
    main()
