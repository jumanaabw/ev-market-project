"""Optional: load the EV market CSV into a MySQL server instead of SQLite.

Requires the extra packages in requirements-mysql.txt (SQLAlchemy and PyMySQL)
and an existing, empty database, for example:

    CREATE DATABASE ev_market CHARACTER SET utf8mb4;

Example
-------
    python scripts/load_to_mysql.py --url "mysql+pymysql://user:password@localhost:3306/ev_market"

Note: the SQLite flow is the one covered by the automated tests. This MySQL
loader is a convenience for connecting Tableau Desktop to a MySQL server.
After loading, run the queries in sql/queries.sql with "CAST(... AS INTEGER)"
changed to "CAST(... AS SIGNED)", which is the MySQL spelling.
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

import config  # noqa: E402
from evmarket import db  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--url", default=os.environ.get("MYSQL_URL"),
                        help='SQLAlchemy URL, e.g. "mysql+pymysql://user:pass@localhost/ev_market" (or set MYSQL_URL)')
    parser.add_argument("--csv", type=Path, help="dataset CSV (default: auto-detect)")
    args = parser.parse_args()

    if not args.url:
        sys.exit("Provide --url or set the MYSQL_URL environment variable.")
    try:
        from sqlalchemy import create_engine
    except ImportError:
        sys.exit("SQLAlchemy and PyMySQL are required: pip install -r requirements-mysql.txt")

    csv = db.resolve_csv(args.csv)
    if csv is None:
        sys.exit("No dataset found. Put ev_market_test.csv in data/ first.")

    df = pd.read_csv(csv)
    engine = create_engine(args.url)
    df.to_sql(config.TABLE_NAME, engine, if_exists="replace", index=False, chunksize=5000, method="multi")
    print(f"Stored {len(df):,} rows in MySQL table {config.TABLE_NAME}")


if __name__ == "__main__":
    main()
