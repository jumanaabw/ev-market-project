"""Run the SQL queries in sql/queries.sql and print the results.

Examples
--------
    python scripts/run_queries.py              # run all queries
    python scripts/run_queries.py --only 3     # run query number 3
    python scripts/run_queries.py --pause      # wait for Enter between queries (handy for screenshots)
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

import config  # noqa: E402
from evmarket import db  # noqa: E402
from evmarket.sqlfile import load_queries  # noqa: E402

LINE = "=" * 100


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", type=Path, default=config.DB_PATH, help="SQLite database file")
    parser.add_argument("--only", type=int, help="run only this query number (1-based)")
    parser.add_argument("--pause", action="store_true", help="wait for Enter after each query")
    args = parser.parse_args()

    db.ensure_database(args.db)
    queries = load_queries()
    if args.only:
        if not 1 <= args.only <= len(queries):
            sys.exit(f"--only must be between 1 and {len(queries)}")
        queries = [queries[args.only - 1]]

    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 50)
    for q in queries:
        print(LINE)
        print(q["title"])
        print("-" * 100)
        print(q["sql"])
        print()
        print(db.run_query(q["sql"], db_path=args.db).to_string(index=False))
        print()
        if args.pause:
            input("Take a screenshot now, then press Enter for the next query...")


if __name__ == "__main__":
    main()
