import pytest

from evmarket import db
from evmarket.generator import generate


@pytest.fixture(scope="session")
def sample_df():
    return generate(n_rows=3000, seed=7)


@pytest.fixture(scope="session")
def db_path(tmp_path_factory, sample_df):
    path = tmp_path_factory.mktemp("db") / "test.db"
    db.load_dataframe(sample_df, path, source="test")
    return path


@pytest.fixture()
def client(db_path):
    from webapp import create_app

    app = create_app({"TESTING": True, "DB_PATH": str(db_path), "AUTO_BUILD_DB": False})
    return app.test_client()
