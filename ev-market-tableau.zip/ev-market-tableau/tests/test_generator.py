import pytest

from evmarket.generator import generate, manufacturer_names
from evmarket.schema import BATTERY_TYPES, COLUMNS, MISSING_RATES


def test_has_37_columns_in_order(sample_df):
    assert list(sample_df.columns) == COLUMNS
    assert len(COLUMNS) == 37


def test_row_count_and_unique_ids(sample_df):
    assert len(sample_df) == 3000
    assert sample_df["vehicle_id"].is_unique


def test_expected_dimensions(sample_df):
    assert sample_df["category"].nunique() == 15
    assert sample_df["market_region"].nunique() == 7
    assert sample_df["manufacturing_country"].nunique() == 10
    assert set(sample_df["battery_type"]) == set(BATTERY_TYPES)
    assert sample_df["model_year"].min() == 2018 and sample_df["model_year"].max() == 2026
    assert len(manufacturer_names(200)) == 200


def test_missing_values_only_in_expected_columns(sample_df):
    with_gaps = {c for c in sample_df.columns if sample_df[c].isna().any()}
    assert with_gaps <= set(MISSING_RATES)
    for col, rate in MISSING_RATES.items():
        assert sample_df[col].isna().mean() < rate * 3 + 0.01


def test_values_are_sensible(sample_df):
    assert (sample_df["price_usd"] > 0).all()
    assert (sample_df["range_km"] > 0).all()
    assert sample_df["customer_rating"].dropna().between(1, 5).all()


def test_solid_state_is_most_durable(sample_df):
    by_type = sample_df.groupby("battery_type")["battery_cycle_life"].mean()
    assert by_type.idxmax() == "Solid-State"


def test_same_seed_gives_same_data():
    a = generate(500, seed=3)
    b = generate(500, seed=3)
    assert a.equals(b)


def test_too_few_rows_rejected():
    with pytest.raises(ValueError):
        generate(10)
