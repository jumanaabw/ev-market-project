import config

PAGES = ["/", "/dashboard", "/story", "/insights", "/about"]
API_TABLES = [
    "sales-by-category", "top-manufacturers", "battery", "regions",
    "yearly", "price-segments", "co2", "best-value",
]


def test_pages_load(client):
    for path in PAGES:
        response = client.get(path)
        assert response.status_code == 200, path
        assert b"EV Market Analytics" in response.data


def test_home_shows_row_count(client):
    assert b"3,000" in client.get("/").data


def test_dashboard_embeds_tableau(client):
    html = client.get("/dashboard").get_data(as_text=True)
    assert "<tableau-viz" in html
    assert config.DASHBOARD_URL in html
    assert "tableau.embedding.3.latest.min.js" in html


def test_story_embeds_tableau(client):
    html = client.get("/story").get_data(as_text=True)
    assert "<tableau-viz" in html
    assert config.STORY_URL in html


def test_insights_has_findings(client):
    html = client.get("/insights").get_data(as_text=True)
    assert "Solid-State" in html
    assert "Annual sales by category" in html


def test_api_kpis(client):
    data = client.get("/api/kpis").get_json()
    assert data["total_rows"] == 3000
    assert data["categories"] == 15


def test_api_tables_return_json_lists(client):
    for name in API_TABLES:
        response = client.get(f"/api/{name}")
        assert response.status_code == 200, name
        body = response.get_json()
        assert isinstance(body, list) and body, name
        assert b"NaN" not in response.data


def test_api_unknown_dataset(client):
    response = client.get("/api/nope")
    assert response.status_code == 404
    assert "available" in response.get_json()


def test_health(client):
    assert client.get("/health").get_json() == {"status": "ok", "rows": 3000}


def test_404_page(client):
    response = client.get("/does-not-exist")
    assert response.status_code == 404
    assert b"page not found" in response.data
