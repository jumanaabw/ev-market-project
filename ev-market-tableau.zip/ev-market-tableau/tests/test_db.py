import sqlite3

import pandas as pd
import pytest

import config
from evmarket import analysis, db
from evmarket.sqlfile import get_query, load_queries


def test_table_and_view_exist(db_path):
    with sqlite3.connect(db_path) as conn:
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    assert {config.TABLE_NAME, config.VIEW_NAME, config.META_TABLE} <= names


def test_row_count_matches(db_path, sample_df):
    result = db.run_query(f"SELECT COUNT(*) AS n FROM {config.TABLE_NAME}", db_path=db_path)
    assert result.loc[0, "n"] == len(sample_df)


def test_view_adds_derived_columns(db_path):
    df = db.run_query(f"SELECT * FROM {config.VIEW_NAME} LIMIT 50", db_path=db_path)
    for col in ("range_per_1000usd", "price_segment", "range_class", "fast_charge_rating", "revenue_est"):
        assert col in df.columns
    assert set(df["price_segment"]) <= {"Budget", "Mid-range", "Premium", "Luxury"}


def test_every_named_query_runs(db_path):
    queries = load_queries()
    assert len(queries) == 9
    for q in queries:
        result = db.run_query(q["sql"], db_path=db_path)
        assert len(result) > 0, q["name"]


def test_get_query_unknown_name():
    with pytest.raises(KeyError):
        get_query("does_not_exist")


def test_top_manufacturers_sorted(db_path):
    df = analysis.top_manufacturers(db_path)
    assert len(df) == 10
    assert df["total_sales"].is_monotonic_decreasing


def test_battery_comparison_sorted_by_cycle_life(db_path):
    df = analysis.battery_comparison(db_path)
    assert df["avg_cycle_life"].is_monotonic_decreasing
    assert df.iloc[0]["battery_type"] == "Solid-State"


def test_correlations_and_insights(db_path):
    corr = analysis.correlations(db_path)
    assert -1 <= corr["price_vs_range"] <= 1
    assert corr["price_vs_battery"] > corr["price_vs_range"]
    assert len(analysis.insights(db_path)) >= 5


def test_load_dataframe_rejects_missing_columns(tmp_path):
    with pytest.raises(ValueError, match="missing required columns"):
        db.load_dataframe(pd.DataFrame({"a": [1]}), tmp_path / "bad.db")


def test_ensure_database_builds_and_reloads_on_csv_change(tmp_path, sample_df):
    csv = tmp_path / "data.csv"
    database = tmp_path / "ev.db"

    sample_df.head(500).to_csv(csv, index=False)
    db.ensure_database(database, csv)
    assert db.run_query("SELECT COUNT(*) AS n FROM ev_market", db_path=database).loc[0, "n"] == 500

    # unchanged CSV -> database is left alone
    before = database.stat().st_mtime_ns
    db.ensure_database(database, csv)
    assert database.stat().st_mtime_ns == before

    # changed CSV -> database is rebuilt
    sample_df.head(800).to_csv(csv, index=False)
    db.ensure_database(database, csv)
    assert db.run_query("SELECT COUNT(*) AS n FROM ev_market", db_path=database).loc[0, "n"] == 800


def test_resolve_csv_explicit_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        db.resolve_csv(tmp_path / "nope.csv")
