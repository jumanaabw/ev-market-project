-- Clean view used by the dashboards.
-- Adds the same derived fields that the Tableau calculated fields create:
-- Range per 1000 USD, Price Segment, Range Class, Fast Charge Rating, Revenue (Est.).
CREATE VIEW vw_ev_clean AS
SELECT
    *,
    ROUND(range_km * 1.0 / price_usd * 1000, 2) AS range_per_1000usd,
    CASE
        WHEN price_usd < 20000  THEN 'Budget'
        WHEN price_usd < 60000  THEN 'Mid-range'
        WHEN price_usd < 120000 THEN 'Premium'
        ELSE 'Luxury'
    END AS price_segment,
    CASE
        WHEN range_km >= 450 THEN 'Long'
        WHEN range_km >= 250 THEN 'Medium'
        ELSE 'Short'
    END AS range_class,
    CASE
        WHEN charging_dc_fast_time_min <= 15 THEN 'Ultra-fast'
        WHEN charging_dc_fast_time_min <= 25 THEN 'Fast'
        ELSE 'Standard'
    END AS fast_charge_rating,
    price_usd * annual_sales_units AS revenue_est
FROM ev_market
WHERE price_usd > 0 AND range_km > 0;
