-- Analysis queries for the EV market table (SQLite).
-- File format: "-- name:" starts a query, "-- title:" is its heading.
-- Used by scripts/run_queries.py and by the Flask app (evmarket/analysis.py).

-- name: overview
-- title: 1. Dataset overview (counts and distinct values)
SELECT
    COUNT(*)                                   AS total_rows,
    COUNT(DISTINCT manufacturer)               AS manufacturers,
    COUNT(DISTINCT category)                   AS categories,
    COUNT(DISTINCT manufacturing_country)      AS countries,
    COUNT(DISTINCT market_region)              AS regions,
    MIN(model_year)                            AS first_year,
    MAX(model_year)                            AS last_year,
    CAST(SUM(annual_sales_units) AS INTEGER)   AS total_sales,
    ROUND(AVG(price_usd), 0)                   AS avg_price_usd,
    ROUND(AVG(range_km), 1)                    AS avg_range_km
FROM ev_market;

-- name: top_manufacturers
-- title: 2. Top 10 manufacturers by total annual sales
SELECT
    manufacturer,
    CAST(SUM(annual_sales_units) AS INTEGER) AS total_sales
FROM ev_market
GROUP BY manufacturer
ORDER BY total_sales DESC
LIMIT 10;

-- name: sales_by_category
-- title: 3. Sales and average price by category
SELECT
    category,
    COUNT(*)                                 AS models,
    CAST(SUM(annual_sales_units) AS INTEGER) AS total_sales,
    ROUND(AVG(price_usd), 2)                 AS avg_price
FROM ev_market
GROUP BY category
ORDER BY total_sales DESC;

-- name: battery_comparison
-- title: 4. Battery technology comparison
SELECT
    battery_type,
    ROUND(AVG(range_km), 1)                       AS avg_range_km,
    ROUND(AVG(charging_dc_fast_time_min), 1)      AS avg_fast_charge_min,
    ROUND(AVG(battery_cycle_life), 0)             AS avg_cycle_life,
    ROUND(AVG(battery_degradation_pct_5yr), 2)    AS avg_degradation_pct
FROM ev_market
GROUP BY battery_type
ORDER BY avg_cycle_life DESC;

-- name: region_summary
-- title: 5. Region-wise performance
SELECT
    market_region,
    COUNT(*)                         AS models,
    ROUND(AVG(price_usd), 0)         AS avg_price,
    ROUND(AVG(customer_rating), 2)   AS avg_rating
FROM ev_market
GROUP BY market_region
ORDER BY models DESC;

-- name: yearly_trend
-- title: 6. Year-wise trend
SELECT
    model_year,
    COUNT(*)                                 AS models,
    ROUND(AVG(range_km), 1)                  AS avg_range_km,
    ROUND(AVG(price_usd), 0)                 AS avg_price,
    CAST(SUM(annual_sales_units) AS INTEGER) AS total_sales
FROM ev_market
GROUP BY model_year
ORDER BY model_year;

-- name: price_segments
-- title: 7. Price segments (uses the vw_ev_clean view)
SELECT
    price_segment,
    COUNT(*)                                 AS models,
    ROUND(AVG(range_km), 1)                  AS avg_range_km,
    ROUND(AVG(battery_capacity_kwh), 1)      AS avg_battery_kwh,
    CAST(SUM(annual_sales_units) AS INTEGER) AS total_sales
FROM vw_ev_clean
GROUP BY price_segment
ORDER BY MIN(price_usd);

-- name: co2_by_category
-- title: 8. CO2 saved by category
SELECT
    category,
    ROUND(AVG(co2_saved_tons_per_year), 2)       AS avg_tons_per_vehicle,
    ROUND(SUM(co2_saved_tons_per_year) / 1000.0, 1) AS total_thousand_tons
FROM ev_market
GROUP BY category
ORDER BY total_thousand_tons DESC;

-- name: best_value_models
-- title: 9. Top 10 cars by range per 1000 USD (price of at least 10,000 USD)
SELECT
    vehicle_id,
    manufacturer,
    category,
    price_usd,
    range_km,
    range_per_1000usd
FROM vw_ev_clean
WHERE price_usd >= 10000
  AND category NOT IN ('Electric Truck', 'Pickup Truck', 'Electric Bus')
ORDER BY range_per_1000usd DESC
LIMIT 10;
