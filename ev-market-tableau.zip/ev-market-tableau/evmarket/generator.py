"""Synthetic EV market dataset generator.

The official dataset (ev_market_test.csv, 100,000 rows x 37 columns) comes from
Skill Wallet and is not redistributed here. This generator builds a stand-in
with the same 37 columns, the same category mix, and category-level averages
(price, annual sales, CO2 saved) and battery-type averages (cycle life,
degradation) taken from the published project report, so the whole pipeline
runs end to end without the original file.

The numbers are SYNTHETIC. Do not quote them as real market statistics.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .schema import BATTERY_TYPES, COLUMNS, COUNTRIES, MISSING_RATES, REGIONS

# ---------------------------------------------------------------------------
# Category profiles
#   share  - relative number of models (matches the report at 100,000 rows)
#   price  - average price in USD            sales - average units per model
#   cap    - typical battery size (kWh)      eff   - Wh per km
#   power  - motor power (kW)                weight- kerb weight (kg)
#   speed  - top speed (km/h)                seats - (min, max)
#   cargo  - boot / load volume in litres    co2   - (min, max) tons per year
#   kind   - light / car / heavy (used for drivetrain and screen size)
# ---------------------------------------------------------------------------
CATEGORIES = {
    "Two-Wheeler Scooter": dict(share=9826, price=2530.6, sales=8654, cap=3.0, eff=30, power=5, weight=120, speed=80, seats=(1, 2), cargo=(0, 40), co2=(1, 2), kind="light",
                                uses=["Daily Commute", "Urban Delivery"]),
    "Sedan": dict(share=8617, price=42557, sales=9088, cap=65, eff=150, power=170, weight=1700, speed=190, seats=(4, 5), cargo=(400, 550), co2=(2, 4), kind="car",
                  uses=["Daily Commute", "Long-Distance Travel", "Family Use"]),
    "Compact SUV": dict(share=8569, price=36528, sales=8884, cap=55, eff=160, power=130, weight=1700, speed=175, seats=(5, 5), cargo=(350, 500), co2=(2, 4), kind="car",
                        uses=["Family Use", "Daily Commute", "Long-Distance Travel"]),
    "Hatchback": dict(share=8571, price=23005, sales=8881, cap=45, eff=140, power=100, weight=1400, speed=160, seats=(4, 5), cargo=(250, 400), co2=(2, 4), kind="car",
                      uses=["Daily Commute", "Family Use"]),
    "Three-Wheeler": dict(share=7527, price=5483, sales=8914, cap=8.0, eff=60, power=10, weight=350, speed=55, seats=(3, 6), cargo=(50, 400), co2=(1, 2), kind="light",
                          uses=["Urban Delivery", "Daily Commute", "Public Transport"]),
    "Crossover": dict(share=7462, price=41105, sales=8681, cap=70, eff=165, power=160, weight=1800, speed=185, seats=(5, 5), cargo=(400, 600), co2=(2, 4), kind="car",
                      uses=["Family Use", "Daily Commute"]),
    "Luxury Sedan": dict(share=6511, price=89867, sales=9035, cap=95, eff=170, power=300, weight=2100, speed=230, seats=(4, 5), cargo=(400, 550), co2=(2, 4), kind="car",
                         uses=["Long-Distance Travel", "Performance", "Daily Commute"]),
    "Micro City Car": dict(share=6404, price=12999.6, sales=9038, cap=20, eff=110, power=40, weight=900, speed=120, seats=(2, 4), cargo=(150, 250), co2=(2, 4), kind="car",
                           uses=["Daily Commute", "Urban Delivery"]),
    "Full-size SUV": dict(share=6457, price=85076, sales=8827, cap=105, eff=230, power=280, weight=2500, speed=200, seats=(6, 8), cargo=(600, 1000), co2=(2, 4), kind="car",
                          uses=["Family Use", "Long-Distance Travel"]),
    "Luxury SUV": dict(share=5375, price=116296, sales=8848, cap=115, eff=240, power=330, weight=2600, speed=210, seats=(5, 7), cargo=(500, 900), co2=(2, 4), kind="car",
                       uses=["Long-Distance Travel", "Family Use", "Performance"]),
    "Van / MPV": dict(share=5382, price=47546, sales=8445, cap=75, eff=220, power=150, weight=2300, speed=150, seats=(7, 9), cargo=(600, 1200), co2=(2, 4), kind="car",
                      uses=["Family Use", "Urban Delivery", "Public Transport"]),
    "Sports Car": dict(share=4287, price=164928, sales=9324, cap=100, eff=190, power=550, weight=1700, speed=300, seats=(2, 4), cargo=(100, 300), co2=(2, 4), kind="car",
                       uses=["Performance"]),
    "Electric Truck": dict(share=5310, price=169007, sales=1244, cap=250, eff=900, power=400, weight=9000, speed=120, seats=(2, 3), cargo=(10000, 40000), co2=(5, 13), kind="heavy",
                           uses=["Heavy Haulage", "Urban Delivery"]),
    "Pickup Truck": dict(share=5393, price=68100, sales=1213, cap=110, eff=260, power=300, weight=2800, speed=170, seats=(4, 5), cargo=(800, 1500), co2=(5, 13), kind="heavy",
                         uses=["Heavy Haulage", "Family Use", "Urban Delivery"]),
    "Electric Bus": dict(share=4309, price=274045, sales=1235, cap=350, eff=1000, power=300, weight=13000, speed=100, seats=(20, 65), cargo=(3000, 12000), co2=(5, 13), kind="heavy",
                         uses=["Public Transport"]),
}

# battery type -> (average cycle life, average 5-year degradation %)
BATTERY_PROFILE = {
    "NMC": (1799, 14.01),
    "LFP": (2498, 10.11),
    "NCA": (1598, 14.02),
    "Sodium-Ion": (1797, 13.98),
    "Solid-State": (2999, 7.36),
}

_PREFIXES = [
    "Surge", "Current", "Elektra", "Velocity", "Watt", "Zap", "Kinetic", "Ion",
    "Volt", "Dynamo", "Ampere", "Flux", "Neo", "Terra", "Aero", "Nova",
    "Pulse", "Spark", "Arc", "Gridline", "Orbit", "Vector", "Helio",
]
_SUFFIXES = ["Works", "Mobility", "Motors", "Dynamics", "Wheels", "Auto", "Rides", "Group", "Automotive"]
_SERIES = ["Aero", "Apex", "Bolt", "Cruz", "Drift", "Edge", "Flux", "Glide", "Halo", "Nova", "Orbit", "Pulse"]


def manufacturer_names(count: int = 200) -> list[str]:
    """Deterministic list of fictional manufacturer names."""
    names = [p + s for p in _PREFIXES for s in _SUFFIXES]
    return names[:count]


def _allocate(total: int, weights) -> np.ndarray:
    """Split `total` into integer counts proportional to `weights`."""
    w = np.asarray(weights, dtype=float)
    raw = w / w.sum() * total
    counts = np.floor(raw).astype(int)
    leftover = total - counts.sum()
    if leftover > 0:
        order = np.argsort(-(raw - counts))
        counts[order[:leftover]] += 1
    return counts


def generate(n_rows: int = 100_000, seed: int = 42) -> pd.DataFrame:
    """Build a synthetic EV market table with the 37 project columns."""
    if n_rows < 100:
        raise ValueError("n_rows must be at least 100 so every category appears")
    rng = np.random.default_rng(seed)
    n = n_rows

    names = list(CATEGORIES)
    profiles = [CATEGORIES[k] for k in names]
    counts = _allocate(n, [p["share"] for p in profiles])
    ci = rng.permutation(np.repeat(np.arange(len(names)), counts))  # category index per row
    category = np.array(names)[ci]

    def per_row(key):
        return np.array([p[key] for p in profiles], dtype=float)[ci]

    normal = lambda: rng.standard_normal(n)  # noqa: E731
    z = normal()  # shared "size / class" factor ties price, battery and power together

    # --- identity -------------------------------------------------------
    makers = np.array(manufacturer_names(200))
    manufacturer = makers[rng.integers(0, len(makers), n)]
    series = np.array(_SERIES)[rng.integers(0, len(_SERIES), n)]
    model_name = pd.Series(manufacturer).str.cat(
        [pd.Series(series), pd.Series(rng.integers(100, 1000, n).astype(str))], sep=" "
    ).to_numpy()
    model_year = rng.integers(2018, 2027, n)
    country = np.array(COUNTRIES)[rng.integers(0, len(COUNTRIES), n)]
    region = np.array(REGIONS)[rng.integers(0, len(REGIONS), n)]

    # --- battery --------------------------------------------------------
    cap_sigma = 0.22
    capacity = per_row("cap") * np.exp(cap_sigma * (0.8 * z + 0.6 * normal()) - cap_sigma**2 / 2)
    capacity = np.clip(capacity, 1.0, 600.0).round(1)
    battery_type = np.array(BATTERY_TYPES)[rng.integers(0, len(BATTERY_TYPES), n)]
    cycle_mean = np.array([BATTERY_PROFILE[b][0] for b in battery_type], dtype=float)
    degr_mean = np.array([BATTERY_PROFILE[b][1] for b in battery_type], dtype=float)
    cycle_life = np.clip(rng.normal(cycle_mean, 120), 500, 5000).round().astype(int)
    degradation = np.clip(rng.normal(degr_mean, 1.0), 1.5, 25).round(2)

    # --- performance ----------------------------------------------------
    efficiency = (per_row("eff") * np.exp(0.10 * normal())).round(1)
    range_km = np.clip(capacity * 1000 / efficiency * 0.95 * np.exp(0.05 * normal()), 50, 660).round(0)
    power = np.clip(per_row("power") * np.exp(0.20 * (0.5 * z + 0.87 * normal())), 2, None).round(0)
    torque = (power * rng.uniform(1.8, 2.6, n)).round(0)

    kind = np.array([p["kind"] for p in profiles])[ci]
    u = rng.random(n)
    drivetrain = np.where(
        kind == "light", "RWD",
        np.where(
            kind == "heavy", np.where(u < 0.7, "RWD", "AWD"),
            np.where(u < 0.35, "FWD", np.where(u < 0.75, "RWD", "AWD")),
        ),
    )
    num_motors = np.where(drivetrain == "AWD", 2, 1)
    sports = category == "Sports Car"
    num_motors = np.where(sports & (drivetrain == "AWD"), rng.choice([2, 3, 4], n, p=[0.6, 0.1, 0.3]), num_motors)

    top_speed = np.clip(per_row("speed") * np.exp(0.08 * normal()), 30, 350).round(0)
    weight = np.clip(per_row("weight") * np.exp(0.08 * normal()) + 5 * (capacity - per_row("cap")), 50, None).round(0)
    accel = np.clip(1.3 * (weight / power) ** 0.8 * np.exp(0.06 * normal()), 2.1, 30).round(1)

    # --- charging -------------------------------------------------------
    dc_time = np.clip(rng.normal(21.1, 5.5, n), 8, 45).round(1)
    max_dc = np.clip(0.7 * capacity * 60 / dc_time, 3, 1000).round(0)
    ac_kw = rng.choice([3.7, 7.4, 11.0, 22.0], n, p=[0.2, 0.4, 0.3, 0.1])
    ac_time = np.clip(capacity / ac_kw * 1.1, 0.3, 40).round(1)
    ports = np.where(category == "Electric Bus", 2, rng.choice([1, 2], n, p=[0.75, 0.25]))

    # --- body and features ---------------------------------------------
    seat_lo, seat_hi = (np.array([p["seats"][i] for p in profiles])[ci] for i in (0, 1))
    seats = seat_lo + np.floor(rng.random(n) * (seat_hi - seat_lo + 1)).astype(int)
    cargo_lo, cargo_hi = (np.array([p["cargo"][i] for p in profiles], dtype=float)[ci] for i in (0, 1))
    cargo = (cargo_lo + rng.random(n) * (cargo_hi - cargo_lo)).round(0)
    screen = np.where(kind == "light", rng.uniform(3, 7, n), rng.uniform(8, 17, n)).round(1)
    autonomous = rng.choice([0, 1, 2, 3, 4, 5], n, p=[0.30, 0.25, 0.25, 0.12, 0.06, 0.02])
    safety = rng.choice([2, 3, 4, 5], n, p=[0.05, 0.15, 0.40, 0.40])

    # --- commercial -----------------------------------------------------
    price_sigma = 0.30
    price = per_row("price") * np.exp(price_sigma * (0.85 * z + 0.53 * normal()) - price_sigma**2 / 2)
    price = np.clip(price, 500, 410_000).round(0)
    insurance = (price * rng.uniform(0.025, 0.05, n)).round(0)
    warranty = rng.choice([3, 4, 5, 6, 8, 10], n, p=[0.15, 0.2, 0.25, 0.15, 0.15, 0.10])
    resale = np.clip(rng.normal(58, 8, n), 25, 90).round(1)
    sales_mean = per_row("sales")
    annual_sales = rng.gamma(shape=2.0, scale=sales_mean / 2.0).round().astype(int)
    rating = np.clip(rng.normal(4.08, 0.35, n), 2.5, 5.0).round(1)

    # --- impact and use -------------------------------------------------
    co2_lo, co2_hi = (np.array([p["co2"][i] for p in profiles], dtype=float)[ci] for i in (0, 1))
    co2 = (co2_lo + rng.random(n) * (co2_hi - co2_lo)).round(2)
    use_case = np.empty(n, dtype=object)
    for idx, prof in enumerate(profiles):
        mask = ci == idx
        use_case[mask] = rng.choice(prof["uses"], int(mask.sum()))

    df = pd.DataFrame({
        "vehicle_id": [f"EV{i:06d}" for i in range(1, n + 1)],
        "model_name": model_name,
        "manufacturer": manufacturer,
        "model_year": model_year,
        "manufacturing_country": country,
        "market_region": region,
        "category": category,
        "battery_capacity_kwh": capacity,
        "battery_type": battery_type,
        "battery_cycle_life": cycle_life,
        "battery_degradation_pct_5yr": degradation,
        "range_km": range_km,
        "efficiency_wh_per_km": efficiency,
        "motor_power_kw": power,
        "torque_nm": torque,
        "num_motors": num_motors,
        "drivetrain": drivetrain,
        "top_speed_kmph": top_speed,
        "acceleration_0_100_sec": accel,
        "max_dc_charging_kw": max_dc,
        "charging_dc_fast_time_min": dc_time,
        "charging_ac_time_hr": ac_time,
        "num_charging_ports": ports,
        "num_seats": seats,
        "weight_kg": weight,
        "cargo_capacity_liters": cargo,
        "infotainment_screen_inch": screen,
        "autonomous_level": autonomous,
        "safety_rating_stars": safety,
        "price_usd": price,
        "insurance_cost_usd_yearly": insurance,
        "warranty_years": warranty,
        "resale_value_pct_3yr": resale,
        "annual_sales_units": annual_sales,
        "customer_rating": rating,
        "co2_saved_tons_per_year": co2,
        "recommended_use_case": use_case,
    })[COLUMNS]

    # Blank out a realistic share of a few columns (kept as nullable ints).
    for col, rate in MISSING_RATES.items():
        series_ = df[col]
        if pd.api.types.is_integer_dtype(series_):
            series_ = series_.astype("Int64")
        df[col] = series_.mask(rng.random(n) < rate)

    return df
