"""Tiny parser for sql/queries.sql.

Each query starts with a "-- name: <id>" line, may have a "-- title: <text>"
line, and runs until the next "-- name:" marker.
"""
from __future__ import annotations

from pathlib import Path

import config


def load_queries(path: str | Path | None = None) -> list[dict]:
    """Return [{"name", "title", "sql"}, ...] in file order."""
    path = Path(path) if path else config.SQL_DIR / "queries.sql"
    queries: list[dict] = []
    current: dict | None = None
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("-- name:"):
            current = {"name": stripped[len("-- name:"):].strip(), "title": "", "lines": []}
            queries.append(current)
        elif stripped.startswith("-- title:") and current is not None:
            current["title"] = stripped[len("-- title:"):].strip()
        elif current is not None:
            current["lines"].append(line)

    result = []
    for q in queries:
        sql = "\n".join(q.pop("lines")).strip()
        result.append({"name": q["name"], "title": q["title"] or q["name"], "sql": sql})
    return result


def get_query(name: str, path: str | Path | None = None) -> str:
    """Return the SQL text of one named query."""
    for q in load_queries(path):
        if q["name"] == name:
            return q["sql"]
    raise KeyError(f"No query named {name!r} in {path or config.SQL_DIR / 'queries.sql'}")
