"""SQLite helpers: build the database from CSV, open it, run queries."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

import config
from .generator import generate
from .schema import REQUIRED_COLUMNS

INDEXED_COLUMNS = [
    "category", "manufacturer", "battery_type", "market_region",
    "manufacturing_country", "model_year",
]


def resolve_csv(explicit: str | Path | None = None) -> Path | None:
    """Return the CSV to load: the explicit path, else the first existing candidate."""
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise FileNotFoundError(f"CSV file not found: {path}")
        return path
    for candidate in config.CSV_CANDIDATES:
        if Path(candidate).is_file():
            return Path(candidate)
    return None


def connect(db_path: str | Path | None = None) -> sqlite3.Connection:
    """Open the database (creates an empty file if it does not exist yet)."""
    return sqlite3.connect(str(db_path or config.DB_PATH))


@contextmanager
def session(db_path: str | Path | None = None):
    """Open the database, commit on success, and always close the connection."""
    conn = connect(db_path)
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def _read_meta(conn: sqlite3.Connection) -> dict:
    try:
        return dict(conn.execute(f"SELECT key, value FROM {config.META_TABLE}").fetchall())
    except sqlite3.OperationalError:
        return {}


def _file_signature(path: Path) -> str:
    st = path.stat()
    return f"{path.resolve()}|{st.st_size}|{st.st_mtime_ns}"


def load_dataframe(df: pd.DataFrame, db_path: str | Path | None = None, source: str = "dataframe") -> int:
    """Write a DataFrame to the ev_market table, then add indexes and the view.

    Returns the number of rows stored.
    """
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"The dataset is missing required columns: {', '.join(missing)}")

    db_path = Path(db_path or config.DB_PATH)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    view_sql = (config.SQL_DIR / "create_view.sql").read_text(encoding="utf-8")

    with session(db_path) as conn:
        conn.execute(f"DROP VIEW IF EXISTS {config.VIEW_NAME}")
        df.to_sql(config.TABLE_NAME, conn, if_exists="replace", index=False, chunksize=10_000)
        for col in INDEXED_COLUMNS:
            if col in df.columns:
                conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{col} ON {config.TABLE_NAME}({col})")
        conn.executescript(view_sql)
        conn.execute(f"CREATE TABLE IF NOT EXISTS {config.META_TABLE} (key TEXT PRIMARY KEY, value TEXT)")
        conn.executemany(
            f"INSERT OR REPLACE INTO {config.META_TABLE} (key, value) VALUES (?, ?)",
            [
                ("source", source),
                ("rows", str(len(df))),
                ("loaded_at", datetime.now(timezone.utc).isoformat(timespec="seconds")),
            ],
        )
    return len(df)


def load_csv(csv_path: str | Path, db_path: str | Path | None = None) -> int:
    """Read a CSV and store it in SQLite. Returns the number of rows stored."""
    csv_path = Path(csv_path)
    df = pd.read_csv(csv_path)
    return load_dataframe(df, db_path, source=_file_signature(csv_path))


def ensure_database(db_path: str | Path | None = None, csv_path: str | Path | None = None) -> Path:
    """Make sure the database exists and matches the CSV that should feed it.

    - No database yet            -> build it.
    - CSV changed since last load -> rebuild it.
    - No CSV anywhere            -> build it from a freshly generated sample.
    """
    db_path = Path(db_path or config.DB_PATH)
    csv = resolve_csv(csv_path)

    meta: dict = {}
    if db_path.is_file():
        with session(db_path) as conn:
            meta = _read_meta(conn)
            has_table = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (config.TABLE_NAME,)
            ).fetchone()
        if not has_table:
            meta = {}

    if csv is not None:
        if meta.get("source") != _file_signature(csv):
            load_csv(csv, db_path)
    elif not meta:
        load_dataframe(generate(5_000), db_path, source="generated")
    return db_path


def run_query(sql: str, params: tuple | dict = (), db_path: str | Path | None = None) -> pd.DataFrame:
    """Run a SELECT and return the result as a DataFrame."""
    with session(db_path) as conn:
        return pd.read_sql_query(sql, conn, params=params)
