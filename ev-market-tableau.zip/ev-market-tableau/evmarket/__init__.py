"""Core library for the EV market analysis project."""

__version__ = "1.0.0"
