"""Column layout of the EV market dataset (37 columns)."""

COLUMNS = [
    # Identity
    "vehicle_id", "model_name", "manufacturer", "model_year",
    "manufacturing_country", "market_region", "category",
    # Battery
    "battery_capacity_kwh", "battery_type", "battery_cycle_life",
    "battery_degradation_pct_5yr",
    # Performance
    "range_km", "efficiency_wh_per_km", "motor_power_kw", "torque_nm",
    "num_motors", "drivetrain", "top_speed_kmph", "acceleration_0_100_sec",
    # Charging
    "max_dc_charging_kw", "charging_dc_fast_time_min", "charging_ac_time_hr",
    "num_charging_ports",
    # Body and features
    "num_seats", "weight_kg", "cargo_capacity_liters",
    "infotainment_screen_inch", "autonomous_level", "safety_rating_stars",
    # Commercial
    "price_usd", "insurance_cost_usd_yearly", "warranty_years",
    "resale_value_pct_3yr", "annual_sales_units", "customer_rating",
    # Impact and use
    "co2_saved_tons_per_year", "recommended_use_case",
]

# Columns the analysis code cannot work without.
REQUIRED_COLUMNS = [
    "manufacturer", "model_year", "manufacturing_country", "market_region",
    "category", "battery_capacity_kwh", "battery_type", "battery_cycle_life",
    "battery_degradation_pct_5yr", "range_km", "charging_dc_fast_time_min",
    "price_usd", "annual_sales_units", "customer_rating",
    "co2_saved_tons_per_year",
]

BATTERY_TYPES = ["NMC", "LFP", "NCA", "Sodium-Ion", "Solid-State"]

REGIONS = [
    "North America", "Europe", "Asia Pacific", "South Asia",
    "Middle East", "Latin America", "Africa",
]

COUNTRIES = [
    "China", "United States", "Germany", "Japan", "South Korea",
    "India", "France", "United Kingdom", "Sweden", "Netherlands",
]

# Share of blank cells per column, as described in the project report.
MISSING_RATES = {
    "resale_value_pct_3yr": 0.03057,
    "battery_cycle_life": 0.02028,
    "customer_rating": 0.01931,
    "infotainment_screen_inch": 0.01506,
    "annual_sales_units": 0.00989,
}
