"""Analysis layer: runs the named SQL queries and derives the key insights.

Results are cached per database file (path, size and modification time), so
the Flask app does not re-run heavy aggregations on every page view and
picks up a reloaded database automatically.
"""
from __future__ import annotations

import functools
import json
from pathlib import Path

import pandas as pd

import config
from . import db
from .sqlfile import get_query

_CACHE: dict = {}


def _stamp(db_path: str | Path | None) -> tuple:
    path = Path(db_path or config.DB_PATH)
    st = path.stat()
    return (str(path), st.st_mtime_ns, st.st_size)


def _cached(func):
    @functools.wraps(func)
    def wrapper(db_path: str | Path | None = None):
        key = (func.__name__, *_stamp(db_path))
        if key not in _CACHE:
            _CACHE[key] = func(db_path)
        value = _CACHE[key]
        return value.copy() if isinstance(value, pd.DataFrame) else dict(value) if isinstance(value, dict) else list(value)
    return wrapper


def _named(name: str, db_path) -> pd.DataFrame:
    return db.run_query(get_query(name), db_path=db_path)


# --- query wrappers ---------------------------------------------------------
@_cached
def kpis(db_path=None) -> dict:
    """Headline numbers for the home page and the API."""
    row = _named("overview", db_path).to_dict(orient="records")[0]
    return {k: (None if pd.isna(v) else v) for k, v in row.items()}


@_cached
def top_manufacturers(db_path=None) -> pd.DataFrame:
    return _named("top_manufacturers", db_path)


@_cached
def sales_by_category(db_path=None) -> pd.DataFrame:
    return _named("sales_by_category", db_path)


@_cached
def battery_comparison(db_path=None) -> pd.DataFrame:
    return _named("battery_comparison", db_path)


@_cached
def region_summary(db_path=None) -> pd.DataFrame:
    return _named("region_summary", db_path)


@_cached
def yearly_trend(db_path=None) -> pd.DataFrame:
    return _named("yearly_trend", db_path)


@_cached
def price_segments(db_path=None) -> pd.DataFrame:
    return _named("price_segments", db_path)


@_cached
def co2_by_category(db_path=None) -> pd.DataFrame:
    return _named("co2_by_category", db_path)


@_cached
def best_value_models(db_path=None) -> pd.DataFrame:
    return _named("best_value_models", db_path)


@_cached
def correlations(db_path=None) -> dict:
    """Pearson correlation of price with battery capacity and with range."""
    df = db.run_query(
        "SELECT price_usd, battery_capacity_kwh, range_km FROM ev_market", db_path=db_path
    )
    return {
        "price_vs_battery": round(float(df["price_usd"].corr(df["battery_capacity_kwh"])), 2),
        "price_vs_range": round(float(df["price_usd"].corr(df["range_km"])), 2),
    }


def price_range_sample(n: int = 6000, seed: int = 1, db_path=None) -> pd.DataFrame:
    """Random sample of price and range, used by the scatter chart."""
    df = db.run_query("SELECT price_usd, range_km FROM ev_market", db_path=db_path)
    return df.sample(min(n, len(df)), random_state=seed)


# --- narrative insights -----------------------------------------------------
def _millions(value: float) -> str:
    return f"{value / 1_000_000:.1f}M"


def insights(db_path=None) -> list[str]:
    """Plain-language findings computed from whatever data is loaded."""
    out: list[str] = []
    cats = sales_by_category(db_path)
    if len(cats) >= 4:
        top3 = cats.head(3)
        bottom3 = cats.tail(3)
        out.append(
            f"{top3.iloc[0]['category']} leads volume with {_millions(top3.iloc[0]['total_sales'])} units, "
            f"followed by {top3.iloc[1]['category']} ({_millions(top3.iloc[1]['total_sales'])}) and "
            f"{top3.iloc[2]['category']} ({_millions(top3.iloc[2]['total_sales'])}). "
            f"{', '.join(bottom3['category'])} sell the fewest units."
        )

    corr = correlations(db_path)
    if corr["price_vs_battery"] > corr["price_vs_range"]:
        out.append(
            f"Price follows battery size more than range: correlation {corr['price_vs_battery']:.2f} "
            f"with battery capacity versus {corr['price_vs_range']:.2f} with range."
        )
    else:
        out.append(
            f"Price follows range more than battery size: correlation {corr['price_vs_range']:.2f} "
            f"with range versus {corr['price_vs_battery']:.2f} with battery capacity."
        )

    if len(cats):
        priciest = cats.sort_values("avg_price", ascending=False).iloc[0]
        out.append(f"{priciest['category']} is the most expensive category at an average of ${priciest['avg_price']:,.0f}.")

    bat = battery_comparison(db_path)
    if len(bat) >= 2:
        best, second = bat.iloc[0], bat.iloc[1]
        out.append(
            f"{best['battery_type']} lasts longest ({best['avg_cycle_life']:,.0f} cycles, "
            f"{best['avg_degradation_pct']:.2f}% degradation over five years), followed by "
            f"{second['battery_type']} ({second['avg_cycle_life']:,.0f} cycles, {second['avg_degradation_pct']:.2f}%)."
        )
        spread = bat["avg_range_km"].max() - bat["avg_range_km"].min()
        if spread < 0.05 * bat["avg_range_km"].mean():
            out.append(
                f"Battery chemistry barely changes range (a spread of {spread:.1f} km between types), "
                f"so durability is the main differentiator."
            )
        else:
            out.append(f"Average range differs by {spread:.1f} km between battery types.")

    reg = region_summary(db_path)
    if len(reg) >= 2:
        share = reg["models"].max() / reg["models"].sum() * 100
        even_share = 100 / len(reg)
        verdict = "Regions are balanced" if share < 1.25 * even_share else "One region stands out"
        out.append(f"{verdict}: the largest ({reg.iloc[0]['market_region']}) holds {share:.1f}% of models.")
    return out


def to_records(df: pd.DataFrame) -> list[dict]:
    """DataFrame -> JSON-safe list of dicts (NaN becomes null)."""
    return json.loads(df.to_json(orient="records"))
